echo $FT_LINE | wc -m | bc 
